#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include<string.h>

#define	BUFFSIZE 4096

int main(int argc, char *argv[]) {
	int  readFileDescriptor, writeFileDescriptor;
	long int n;
	char buf[BUFFSIZE];
	
	if (argc != 3){
		printf("Usage: %s file1.txt file2.txt\n", argv[0]);
		exit (-1);
	}
	
	readFileDescriptor = open(argv[2], O_RDONLY);
	writeFileDescriptor = open(argv[1], O_CREAT|O_WRONLY|O_APPEND, 0700);

	if (readFileDescriptor == -1 || writeFileDescriptor == -1){
		printf("Error When Opening File Plz Check \n");
		exit (-1);
	}
	
	if (strcmp(argv[1],argv[2])==0){
		printf("Same Files given in argument Need to specify 2 different files to copy contents from one to another \n");
		printf("Given Files : \n File1 is %s \t  File 2 is %s",argv[1],argv[2]);
		exit (-1);
	}
    
    if (lseek(readFileDescriptor, 0, SEEK_CUR) >= 0){
	while ((n = read(readFileDescriptor, buf, BUFFSIZE)) > 0){
		if (write(writeFileDescriptor, buf, n) != n){
			printf("Error while writing to output file\n");
			exit (-1);
		}
	}
    } else {
    	
    	printf("lseek error (Part 1)\n");
		exit (-1);
	
	
    }
	if (n < 0){
		printf("Error while reading input file no contents read \n");
		exit (-1);
	}

	close(readFileDescriptor);
	close(writeFileDescriptor);

	return 0;
	
}
