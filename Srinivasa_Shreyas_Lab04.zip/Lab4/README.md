I, Shreyas Srinivasa, declare that I have completed this assignment
completely and entirely on my own, without any unathorized consultation
from others or unathorized access to online websites. I have read the
UAB Academic Honor Code and understand that any breach of the UAB
Academic Honor Code may result in severe penalties.

Student Signature/Initials: SS

Date: Feb 2 2023

I had used strcmp function to compare 2 arguments and lseek function to
move the pointer. Along with it used open functions to open the
destination file which is second argument in read only mode with
O\_RDONLY. and opened file1 to write the contents.

Command to run : gcc -o ss ll44.c

Execute : ./ss l1.txt l2.txt
