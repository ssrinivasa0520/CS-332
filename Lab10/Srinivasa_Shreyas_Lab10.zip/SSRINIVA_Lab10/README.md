# Lab-10: Fork and Exec and I/O Streams

## Name: SHREYAS SRINIVASA

## Honor Code:

I, SHREYAS SRINIVASA, declare that I have completed this assignment completely and entirely on my own, without any unathorized consultation from others or unathorized access to online websites. I have read the UAB Academic Honor Code and understand that any breach of the UAB Academic Honor Code may result in severe penalties.

Student Signature/Initials: SS

Date: 04/03/2023

## Assignment

This homework is very similar to Lab-7 homework assignment, the only change required is highlighted below. You can start with the Lab-7 homework solution: lab7_solution.c

Write a program that takes a filename as a command-line argument and performs the
following steps:

1. Open the file specified as the command-line argument.

2. Read contents of the file one-line at a time.

3. Use fork-exec to create a new process that executes the program specified in the
input file along with the arguments provided.

4. The child process will redirect the standard output stream (stdout) to a
file <pid>.out and the standard error stream (stderr) to the file <pid>.err. Note
that <pid> here corresponds to the process id of the child process. As a result of
this change you will not see any output from the child process on the terminal, you
have to look at the corresponding <pid>.out or <pid>.err file for the corresponding
output and error messages.

5. The parent process will make note of the time the program was started (you can
use a timer such as the time function defined in <time.h> to capture the time before
the fork method is invoked, you can find out more about time function by
typing man time).

6. Then the parent process will wait for the child process to complete and when the
child process terminates successfully, the parent process will capture the time the

child process completed (you can again use a timer function to capture the time
when the wait function returns).

7. Open a log file (say, output.log) and write the command executed along with
arguments, start time of the process, and the end time of the process separated by
tabs. Use ctime function to write the time in a human readable form.

8. Go to step 2 and repeat the above process for very command in the input file.
Please use standard I/O library function calls for all I/O operations in this assignment.
Make sure you open the file in the appropriate modes for reading and writing and also
make sure to close the file and flush the file, especially when you are writing the file.

## About the program

1. The lines are read from the file in a loop and for each file a child process is spawned.
2. The child process uses the appropriate exec call to execute the command along with the arguments. The line read from the input file is broken down into tokens which are inserted into an array of char pointers, which is then passed as an argument to the exec call.
3. The parent process waits for the child to finish and notes the starting and ending timestamps o the process.
4. The original line read from the input file along with the timestamps are then written to a new file "output.log"
5. We duplicate the stdout and stderr file descriptors using the dup2() system call and esentially redirect all the outputs and errors to text files
6. There is a <pid>.out and <pid>.err created for each new child process spawned 

## Instrctions to execute(Linux)

1. gcc -Wall -O -o lab10 lab10.c
2. ./lab10 <commands.txt>
