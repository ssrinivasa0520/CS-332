char *current_datetime_str();
char *duplicate(char *s);
char *duplicate_until_newline(char *s);
char *left_strip(char *s);
int is_space(char c);
int open_file(char *filename);
char **create_exec_args(char *line);
int read_line(char *s, int n);