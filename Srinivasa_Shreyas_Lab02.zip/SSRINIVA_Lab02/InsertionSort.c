#include <stdio.h>

int main() {

	int N;

	printf("Please enter number of elements in array:-");
	scanf("%d",&N);
	
	int arr[N];
	
	for(int i = 0; i < N; i++) {
		printf("Please enter element %d of array:-", i + 1);
		scanf("%d", &arr[i]);
	}
	
        
        printf("Given array is:\n");
        printf("[");
        for (int i=0; i<N-1; i++){
            printf("%d ,",arr[i]);
        }
        printf("%d]\n", arr[N-1]);
        
        int temp, currLoc;
        for (int i=1; i<N; i++){
            currLoc = i;
            while (currLoc > 0 && arr[currLoc-1] > arr[currLoc]){
                temp = arr[currLoc];
                arr[currLoc] = arr[currLoc-1];
                arr[currLoc-1] = temp;
                currLoc--;
            }
        } 
        
        printf("Sorted array is:\n");
        printf("[");
        for (int i=0; i<N-1; i++){
            printf("%d ,",arr[i]);
        }
        printf("%d]\n", arr[N-1]);
        
	return 0;
}
