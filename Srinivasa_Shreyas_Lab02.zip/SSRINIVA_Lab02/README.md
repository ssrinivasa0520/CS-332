# Lab-02: Arrays, GDB, C vs. Java

## Name: 

## Honor Code:

I, SHREYAS SRINIVASA, declare that I have completed this assignment completely and entirely on my own, without any unathorized consultation from others or unathorized access to online websites. I have read the UAB Academic Honor Code and understand that any breach of the UAB Academic Honor Code may result in severe penalties.

Student Signature/Initials: SS

Date: 1/19/2023

## Assignment:

Write a program in C to implements the insertion sort algorithm.

1. Prompt the user to enter the size of the array *N*.

2. Read in each element of the array with the *scanf()* function.

3. Print the unsorted array.

4. Utilize the provided file *InsertionSort.java* file to implement insertion sort.

https://github.com/UAB-CS-332-532/Lab-02/blob/ba5ec347a13e5cc447c49037a0600be89ed30cab/InsertionSort.java

5. Print the sorted array.

## Optional (Do not Include in Submission)

- Use one of the random functions (e.g. drand48(), lrand48(), or mrand48()) to generate random number for each entry.

## About the program

C implementation of insertion sort

## Instrctions to execute(Linux)

1. cc InsertionSort.c -o InsertionSort.out
2. ./InsertionSort.out
