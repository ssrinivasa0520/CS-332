# HW-01: Practice C Programming

## Name: Shreyas Srinivasa

## Honor Code:

I, SHREYAS SRINIVASA, declare that I have completed this assignment completely and entirely on my own, without any unathorized consultation from others or unathorized access to online websites. I have read the UAB Academic Honor Code and understand that any breach of the UAB Academic Honor Code may result in severe penalties.

Student Signature/Initials: SS

Date: 1/22/2023

## About the program

1. Since it is very complex to return an array with mixed datatypes in C, arrayDetails() returns an array of float datatype to keep it simple
2. Code which has been used to test the functions has been commented out in the main function.

## Instrctions to execute(Linux)

1. cc SSRINIVA_HW01.c -o SSRINIVA_HW01.out -lm
2. ./SSRINIVA_HW01.out
