#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <stdlib.h>


// Helper function to check if a number is prime
int checkPrime(int i, int n) {
	if(i > sqrt(n)) return 1;
	if(n % i == 0) return 0;
	return checkPrime(i + 1, n);
}


void intro332532(int n) {
	if(n % 3 == 0 && n % 5 == 0) {
		printf("UAB CS 332&532\n");
	} else if(n % 3 == 0) {
		printf("CS\n");
	} else if(n % 5 == 0) {
		printf("UAB\n");
	} else if(checkPrime(2, n) == 1) {
		printf("Go Blazers\n");
	} else {
		printf("%d\n", n * n * n);
	}
}

// bool literals cannot be printed directly
bool UABNumber() {
	int n2;
	printf("Enter an integer:-");
	scanf("%d", &n2);
	
	int sum = 0;
	for(int i = 1; i <= n2 / 2; i++) {
		if(n2 % i == 0) sum += i;
	}
	return sum == n2;
}

int reverseNum(int n3) {

	int N = 0;
	while(n3 > 0) {
		N = (N * 10) + (n3 % 10);
		n3 /= 10;
	}
	return N;
}

int smallerThanIndex() {
	int l;
	printf("Enter the size of the array:-");
	scanf("%d", &l);
	int arr[l];
	printf("Enter the elements of the array:-");
	for(int i = 0; i < l;i++) scanf("%d", &arr[i]);
	int c = 0;
	for(int i = 0; i < l;i++) {
		if(*(arr + i) < i) c++;
	} 
	return c;
}

// Return a double array for convenience
float* arrayDetails() {
	int l, min = 0, max = 0; float sum = 0;
	printf("Enter the size of the array:-");
	scanf("%d", &l);
	int arr[l];
	printf("Enter the elements of the array:-");
	for(int i = 0; i < l;i++) {
		scanf("%d", &arr[i]);
		if(arr[i] < arr[min]) min = i;
		if(arr[i] > arr[max]) max = i;
		sum += arr[i];
	};
	static float result[6];
	
	result[0] = l;
	result[1] = arr[min];
	result[2] = min;
	result[4] = arr[max];
	result[5] = max;
	result[3] = floor((sum / l)*100+0.5)/100;
	
	return result;
	
}

// Code to test the functions is writtern here
int main() {
	
	//intro332532(3);
	//intro332532(70);
	//intro332532(4);
	//intro332532(17);
	//intro332532(30);
	
	//printf("%s\n", UABNumber() ? "True" : "False");
	//printf("%s\n", UABNumber() ? "True" : "False");
	//printf("%s\n", UABNumber() ? "True" : "False");
	//printf("%s\n", UABNumber() ? "True" : "False");
	
	//printf("%d\n", reverseNum(1234));
	//printf("%d\n", reverseNum(29));
	//printf("%d\n", reverseNum(10001));
	
	
	//printf("%d\n", smallerThanIndex());
	//printf("%d\n", smallerThanIndex());
	//printf("%d\n", smallerThanIndex());
	
	// float *result = arrayDetails();
	
	// for(int i = 0; i < 6; i++) printf("%.2f ",result[i]);

	// printf("\n");
	
	return 0;
}
