# Lab-09: Signal Handling

## **Outcomes:**

- Understand what a signal is (in relationship to Unix).

- Understand the roles signals play in a Unix environment.

- Understand what might cause a signal to be sent.

- Understand what the signals SIGINT, SIGQUIT, SIGTSTP, SIGUSR1, SIGUSR2 do.

- Understand the three responses a process might have to a signal.

- Understand what signal catching is.

- Be able to use the signal()/sigaction() function to modify the default response (disposition) of a process to a signal.

## **Objective:**

Modify the program _forkexecvp.c_ (found on GitHub and Canvas) such that when you type Control-C the child process is interrupted and when you type Control-Z the child process is suspended. In both cases,the parent process should continues to wait until it receives a quit signal (Control-\).

## **Submission:**

- Your submission to Canvas should include a README file (including basic information about your program) and your source code as a .c file)

- Be sure to submit your README and your source code in a ZIP file.

- Be sure to include the independent completion code snippet at the top of your source code.

I, SHREYAS SRINIVASA, declare that I have completed this assignment completely and entirely on my own, without any unathorized consultation from others or unathorized access to online websites. I have read the UAB Academic Honor Code and understand that any breach of the UAB Academic Honor Code may result in severe penalties.

Student Signature/Initials: SS

Date: 03/27/2023

## **About the program:**

1. Simple program to illustrate the use of fork-exec-wait pattern along with signal handling.
2. This version uses execvp and command-line arguments to create a new process.
3. This version makes the parent process ignore SIGINT and SIGTSTP signals generated while they cause default behaviors in the forked process.
4. SIGCHLD handling is used to display the exit status of the child process. Parent process can be terminated by using SIGQUIT or SIGTERM.
5. To Compile: gcc -Wall forkexecvp-signals.c
6. To Run: ./a.out <command> [args]
