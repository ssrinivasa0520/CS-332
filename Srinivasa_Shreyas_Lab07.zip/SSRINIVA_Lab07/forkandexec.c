#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

#define LINESIZE 1024

char *stripNewline(char *str)
{
	int len = strlen(str);
	if (str[len - 1] == '\n')
		str[len - 1] = '\0';
	return str;
}

int main(int argc, char **argv)
{
	pid_t pid;
	int status;
	char line[LINESIZE];

	if (argc < 2)
	{
		printf("Usage: %s <command> [args]\n", argv[0]);
		exit(-1);
	}

	FILE *fin = fopen(argv[1], "r");
	FILE *fout = fopen("output.log", "w");

	if (fin == NULL)
	{
		printf("Error reading input file %s\n", argv[1]);
		exit(-1);
	}
	if (fout == NULL)
	{
		printf("Error opening the output file output.log\n");
		exit(-1);
	}

	while (fgets(line, sizeof(line), fin) != NULL)
	{
		// if(feof(fin)) break;

		// printf("[%ld] Line:- %s\n", (long)getpid(), line);

		char *tokens[10];
		int i = 0;
		char lineCopy[1024];
		time_t t;
		char *startTime, *endTime;

		stripNewline(line);

		strcpy(lineCopy, line);

		tokens[i] = strtok(lineCopy, " ");

		while (tokens[i] != NULL)
			tokens[++i] = strtok(NULL, " ");
		tokens[++i] = NULL;

		pid = fork();
		if (pid == 0)
		{
			// printf("Tokens:- %s %s\n", tokens[0], tokens[1]);
			if ((strchr(tokens[0], '/') != NULL || strchr(tokens[0], '\\') != NULL) || strchr(tokens[1], '-') == NULL)
				execvp(tokens[0], &tokens[0]);
			else
				execvp(tokens[0], &tokens[1]);
			perror("execv");
			exit(-1);
		}
		else if (pid > 0)
		{
			time(&t);
			startTime = stripNewline(ctime(&t));
			wait(&status);
			time(&t);
			endTime = stripNewline(ctime(&t));

			printf("[%ld] Line:- %s\n", (long)getpid(), line);

			if (WIFEXITED(status))
			{
				printf("Child process exited with status = %d\n", WEXITSTATUS(status));
				fprintf(fout, "%s\t%s\t%s\n", line, startTime, endTime);
			}
			else
			{
				printf("Child process did not terminate normally!\n");
			}
		}
		else
		{
			perror("fork");
			exit(EXIT_FAILURE);
		}
	}

	fclose(fin);
	fclose(fout);

	printf("[%ld]: Exiting program .....\n", (long)getpid());

	return 0;
}
