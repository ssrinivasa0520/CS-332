# Lab-07: Fork and Exec

## Name: SHREYAS SRINIVASA

## Honor Code:

I, SHREYAS SRINIVASA, declare that I have completed this assignment completely and entirely on my own, without any unathorized consultation from others or unathorized access to online websites. I have read the UAB Academic Honor Code and understand that any breach of the UAB Academic Honor Code may result in severe penalties.

Student Signature/Initials: SS

Date: 03/05/2023

## Assignment

Objective: Write a program that **takes a filename as a command-line argument** and performs the following steps:

1.	Open the file provided as a command-line argument.

2.	Read the contents of the file one-line at a time (use fgets or getline).

3.	Use fork-exec to create a new process that executes the program specified in the input file along with the arguments provided.

4.	The parent process will make note of the time the program was started (you can use a timer such as the time function defined in <time.h> to capture the time before the fork method is invoked, you can find out more about time function by typing man time).

5.	Then the parent process will wait for the child process to complete and when the child process terminates successfully, the parent process will capture the time the child process completed (you can again use a timer function to capture the time when the wait function returns).

6.	Open a log file (say, output.log) and write the command executed along with arguments, start time of the process, and the end time of the process separated by tabs. Use **ctime function to write the time in a human readable form.**

7.	Go to step 2 and repeat the above process for very command in the input file.
Please use standard I/O library function calls for all I/O operations in this assignment. Make sure you open the file in the appropriate modes for reading and writing and also make sure to close the file, especially when you are writing the file.


Here is a sample input file:


```
uname -a
/sbin/ifconfig
/home/UAB/puri/CS332/lab7/hw1 500
/home/UAB/puri/CS332/lab7/hw1 1000
```

Note: You will need to provide a different path for the hw1 executable.
Note: There might be more than one argument to the command (i.e. echo hello world).

Here is the corresponding sample output log file:

```
uname -a    Thu Oct 10 17:43:44 2019    Thu Oct 10 17:43:44 2019
/sbin/ifconfig    Thu Oct 10 17:43:44 2019    Thu Oct 10 17:43:44 2019
/home/UAB/puri/CS332/lab7/hw1 500    Thu Oct 10 17:43:45 2019    Thu Oct 10 17:43:46 2019
/home/UAB/puri/CS332/lab7/hw1 1000    Thu Oct 10 17:43:46 2019    Thu Oct 10 17:43:57 2019
```

Hints: 
You can download the sample C program hw1.c (this is an old homework assignment). This program has some similar functions, feel free to use them.  Compile the program using the following command:

`
$ gcc -Wall -O -o hw1 hw1.c
`

https://github.com/UAB-CS-332-532/Lab-07/blob/265a6575709d22aefbd3a69ae72967555b36fdc1/hw1.c

## About the program

1. The lines are read from the file in a loop and for each file a child process is spawned.
2. The child process uses the appropriate exec call to execute the command along with the arguments. The line read from the input file is broken down into tokens which are inserted into an array of char pointers, which is then passed as an argument to the exec call.
3. The parent process waits for the child to finish and notes the starting and ending timestamps o the process.
4. The original line read from the input file along with the timestamps are then written to a new file "output.log" 

## Instrctions to execute(Linux)

1. gcc -Wall -O -o forkandexec forkandexec.c
2. ./forkandexec <filename>
