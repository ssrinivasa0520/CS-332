#include <stdio.h>

void hello() {
    printf("HELLO!!!\n");
}