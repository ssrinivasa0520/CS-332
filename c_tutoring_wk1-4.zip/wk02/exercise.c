/** Extend the program from the previous example to calculate the average of 
 * of the given array elements.
 */