#include <stdio.h>
#include<math.h>

// Instrctions to execute(Linux)
// gcc prime.c -lm -o prime.out
// ./prime.out

int checkPrime(int i, int n) {
	if(i > sqrt(n)) return 1;
	if(n % i == 0) return 0;
	return checkPrime(i + 1, n);
}

int main(int argc, char **argv) {

    int givenNumber;
    printf("Enter a number:-");
    scanf("%d", &givenNumber);
    
    if(checkPrime(2, givenNumber) == 1) printf("The given number is prime\n");
    else printf("The given number is not prime\n");
    
    return 0;
}
