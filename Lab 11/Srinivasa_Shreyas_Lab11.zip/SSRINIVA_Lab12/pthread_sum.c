/*
    I, SHREYAS SRINIVASA, declare that I have completed this assignment completely and entirely on my own, without any unathorized consultation from others or unathorized access to online websites. I have read the UAB Academic Honor Code and understand that any breach of the UAB Academic Honor Code may result in severe penalties.

    Student Signature/Initials: SS

    Date: 04/07/2023
*/
/*
  Simple Pthread Program to find the sum of a vector.
  Uses mutex locks to update the global sum.
  Arguments to the thread now passed through structures
  Author: Originally Purushotham Bangalore, modified by Shreyas Srinivasa
  Date: April 07, 2023

  To Compile: gcc -O -Wall pthread_psum.c -lpthread
  To Run: ./a.out 1000 4
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

int N, size;
double *a, sum = 0.0;

typedef struct args
{
  double *a, *sum;
  int N, size;
  long tid;
} ARGS;

ARGS *args;

void *compute(void *arg)
{
  int myStart, myEnd, myN, i;
  ARGS *args = (ARGS *)arg;

  int N = args->N;
  int size = args->size;
  long tid = args->tid;

  // determine start and end of computation for the current thread
  myN = N / size;
  myStart = tid * myN;
  myEnd = myStart + myN;
  if (tid == (size - 1))
    myEnd = N;

  // compute partial sum
  double mysum = 0.0;
  for (i = myStart; i < myEnd; i++)
    mysum += args->a[i];

  // grab the lock, update global sum, and release lock
  pthread_mutex_lock(&mutex);
  *(args->sum) += mysum;
  pthread_mutex_unlock(&mutex);

  return (NULL);
}

int main(int argc, char **argv)
{
  long i;
  pthread_t *tid;

  if (argc != 3)
  {
    printf("Usage: %s <# of elements> <# of threads>\n", argv[0]);
    exit(-1);
  }

  N = atoi(argv[1]);    // no. of elements
  size = atoi(argv[2]); // no. of threads

  // allocate vector and initialize
  tid = (pthread_t *)malloc(sizeof(pthread_t) * size);
  a = (double *)malloc(sizeof(double) * N);
  for (i = 0; i < N; i++)
    a[i] = (double)(i + 1);

  // create arg structure
  args = (ARGS *)malloc(sizeof(ARGS) * size);

  // create threads
  for (i = 0; i < size; i++)
  {
    args[i].tid = i;
    args[i].N = N;
    args[i].a = a;
    args[i].size = size;
    args[i].sum = &sum;
    pthread_create(&tid[i], NULL, compute, (void *)&args[i]);
  }

  // wait for them to complete
  for (i = 0; i < size; i++)
    pthread_join(tid[i], NULL);

  printf("The total is %g, it should be equal to %g\n",
         sum, ((double)N * (N + 1)) / 2);

  return 0;
}
