# Lab-12: Threads and Mutexes

## Name: SHREYAS SRINIVASA

## Honor Code:

I, SHREYAS SRINIVASA, declare that I have completed this assignment completely and entirely on my own, without any unathorized consultation from others or unathorized access to online websites. I have read the UAB Academic Honor Code and understand that any breach of the UAB Academic Honor Code may result in severe penalties.

Student Signature/Initials: SS

Date: 04/07/2023

## Assignment

1. Modify the pthread_sum.c program to create a structure and pass the structure as
argument to the thread creation function instead of using global variables a, sum, N,
and size.

2. You have to create a structure that contains the variables a and sum with
type double, variables N and size with type int, and variable tid with type long or int.

3. You have to create an instance of this structure specific to each thread and pass the
structure as an argument to the corresponding thread creation function. 

4. Test the program for different values of N and number of threads and make sure that the result
is correct.

## About the program

1. The example to compute the sum of all elements in a vector was modified to allow the start routine to receive the required arguments in a single structure argument
2. A separate structure was created for each thread, but the sum property is a pointer that references the global sum variable
3. The required arguments are extracted from the structure in the routine. The calculated partial sum of the segment is added to the global sum using the sum pointer passed through the structure
4. A mutex is used for synchronized access to the global sum variable.
5. Everything else works as usual. The main thread blocks till all the child threads finish execution and then prints the calculated sum.

## Instructions to execute

1. To Compile: gcc -O -Wall pthread_psum.c -lpthread
2. To Run: ./a.out 1000 4
